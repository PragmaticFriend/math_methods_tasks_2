import numpy as np
import pandas as pd
import scipy
import nashpy as nash
from scipy.linalg import solve

import seaborn as sns
import matplotlib.pyplot as plt

import random

try:
  from random_facts import all_facts
except:
  pass

try:
  from math_m_modules import bimatrix_solve
except Exception as e:
  pass

import os

exit_commands_list = ['exit']
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def validate_input(value, is_float=False)->bool:
  try:
    if not is_float:
      int(value)
      if int(value) <= 0:
        return False
      
      return True
    else:
      float(value)
      if float(value) <= 0:
        return False

      return True
  except ValueError:
    return False

def get_company_data(company: str) -> list:
  print(f"Введите количество стратегий для компании {company}. (Целое число > 0)")
  cnt = input("-> ") 
  if cnt in exit_commands_list:
    return False

  while not validate_input(cnt):
    if cnt in exit_commands_list:
      return False
    print(f"{bcolors.FAIL}Введите целое положительное число.{bcolors.ENDC}")
    cnt = input("-> ")
    
  values_list = []
  for i in range(int(cnt)):
    inp_text = f" Введите название {i+1} стратегии компании {company} : "
    value = input(inp_text) 
    if value in exit_commands_list:
      return False
    values_list.append(value)
  return values_list


def get_matrix_values(n, m):
  print(f"Введите матрицу весовых коэффициентов поэлементно")
  matrix_values = []

  iter_cnt = 0
  for i in range(n):
    for j in range(m):
      iter_cnt+=1
      if iter_cnt > 6 and iter_cnt % 4 == 0:
        print(f"    Случайный факт, пока Вы вводите данные: " + random.choice(all_facts.split('\n')).strip())

      value = input(f"  Введите элемент строки {i+1} столбца {j+1} : ")

      while not validate_input(value):
        if value in exit_commands_list:
          return False
        print(f"{bcolors.FAIL}Введите целое положительное число.{bcolors.ENDC}")
        value = input(f"  Введите элемент строки {i+1} столбца {j+1} : ")

      matrix_values.append(int(value))

  return matrix_values


def get_input_data_task1() -> pd.DataFrame:
  """
  Ввод с клавиатуры для задания 1
  """

  a_values = get_company_data('A')
  if not a_values:
    print("User Exit")
    return

  b_values = get_company_data('Б')
  if not b_values:
    print("User Exit")
    return

  matrix_values = get_matrix_values(a_values.__len__(), b_values.__len__())
  if not matrix_values:
    print("User Exit")
    return

  matrix_np = np.array(matrix_values)
  matrix_np = matrix_np.reshape(a_values.__len__(), b_values.__len__()) 

  df = pd.DataFrame(matrix_np, columns=b_values, index=a_values)
  return df


def get_input_data_task2() -> tuple:
  """
  Ввод с клавиатуры для задания 2
  """

  a_values = get_company_data('A')
  if not a_values:
    print("User Exit")
    return

  b_values = get_company_data('Б')
  if not b_values:
    print("User Exit")
    return

  print("Матрица весовых коэффициентов для компании А")
  matrix_values_a = get_matrix_values(a_values.__len__(), b_values.__len__())
  if not matrix_values_a:
    print("User Exit")
    return

  a_matrix_np = np.array(matrix_values_a)
  a_matrix_np = a_matrix_np.reshape(a_values.__len__(), b_values.__len__()) 
  df_a = pd.DataFrame(a_matrix_np, columns=b_values, index=a_values)

  print("Матрица весовых коэффициентов для компании Б")
  matrix_values_b = get_matrix_values(a_values.__len__(), b_values.__len__())
  if not matrix_values_b:
    print("User Exit")
    return

  b_matrix_np = np.array(matrix_values_b)
  b_matrix_np = b_matrix_np.reshape(a_values.__len__(), b_values.__len__()) 
  df_b = pd.DataFrame(b_matrix_np, columns=b_values, index=a_values)

  return df_a, df_b


def get_csv_data(task_num, file_path) -> pd.DataFrame():
  print(f"Считывание файла {file_path}\nОбратите внимание, что ячейка первой строки первого столба должна быть пустой (A1)")
  
  validate_float = False
  if task_num == 3:
    print("Обратите внимание, что последняя СТРОКА в файле должена содержать данные о вероятностях")
    validate_float = True

  df = pd.read_csv(file_path , encoding='utf-8', index_col=0)

  if not validate_dataframe(df, float_val=validate_float):
    return False
  return df


def validate_dataframe(df, float_val=False, st_app=False):
  df_n = df.reset_index()
  df_n.index += 1

  try:
    df_n.drop(['index'], axis=1, inplace=True)
  except Exception as e:
    pass
  
  df_n = df_n.rename(columns={x:y+1 for x,y in zip(df_n.columns,range(0,len(df_n.columns)))})

  for i, row in df_n.iterrows():
    for j, item in enumerate(row):
      if not validate_input(item, is_float=float_val):
        print(f'{bcolors.FAIL}В матрице сожержится недопустимое значение{bcolors.ENDC}\n{item}\nНомер строки: {i}\nНомер столбца: {j+1}')
        if st_app:
          return (f"В матрице сожержится недопустимое значение **'{item}'** Номер строки: {i}\nНомер столбца: {j+1}")
        return False
  return True


def solve_zero_sum_game(df):
  """
  Задача 1

  Описание игры:
  Считаем, что компания А (Строки) выбирает свою стратегию так, 
  чтобы получить максимальный свой выигрыш, а компания Б (Столбцы) выбирает свою стратегию так, 
  чтобы минимизировать выигрыш игрока I.
  """

  player_a_indexes = {}
  for num, vals in enumerate(df.iterrows()):
    player_a_indexes[f"{num+1}_{vals[0]}"] = min(vals[1])

  player_a_win = max(player_a_indexes, key=player_a_indexes.get)

  # Оптимальная чистая стратегия для игрока А
  sub_task_1 = (player_a_win.split("_")[0], player_a_win.split("_")[1])

  # Цена игры для игрока А при выборе чистой оптимальной стратегии
  sub_task_2 = int(player_a_indexes[player_a_win])

  player_b_indexes = {}
  for num, vals in enumerate(df.T.iterrows()):
    player_b_indexes[f"{num+1}_{vals[0]}"] = max(vals[1])

  player_b_win = min(player_b_indexes, key=player_b_indexes.get)

  # Оптимальная чистая стратегия для игрока Б
  sub_task_3 = (player_b_win.split("_")[0], player_b_win.split("_")[1])

  # Цена игры для игрока Б при выборе оптимальной стратегии
  sub_task_4 = int(player_b_indexes[player_b_win])

  print("A indx")
  print(player_a_indexes)
  print("B indx")
  print(player_b_indexes)
  if sub_task_2 != sub_task_4:
    # print("Отсутствие седловой точки")
    # print(f"Цена игры располагается в пределах от {min(sub_task_2, sub_task_4)} до {max(sub_task_2, sub_task_4)}")
    is_sedl_dot = False
  else:
    # print("Найдена седловая точка")
    is_sedl_dot = True

  df_arr_a = df.to_numpy()
  df_arr_b = df.T.to_numpy()
  
  print("Solving game")
  game_1 = nash.Game(df_arr_a)
  strategy = list(game_1.support_enumeration())
  print("Game solved")
  #nash 
  print(strategy)
  try:
    
    sub_task_5 = strategy[0][0]
    sub_task_6 = strategy[0][0].dot(df_arr_a).dot(strategy[0][1])

    df_5 = pd.DataFrame(columns=df.columns)
    data_to_append = {}
    for i in range(len(df.columns)):
      data_to_append[df.columns[i]] = sub_task_5[i]

    df_5 = df_5.append(data_to_append, ignore_index=True)
    sub_task_5 = df_5

  except Exception as e:
    sub_task_5 = 'Решение не найдено ' + str(strategy)
    sub_task_6 = 'Решение не найдено ' + str(strategy)

  print(sub_task_1, sub_task_2, sub_task_3, sub_task_4, sub_task_5, sub_task_6)
  return sub_task_1, sub_task_2, sub_task_3, sub_task_4, sub_task_5, sub_task_6, is_sedl_dot


def solve_bimatrix_game(df_a, df_b)->list:
  """
  Задача 2
  
  """
  bimatrix_game = nash.Game(df_a.to_numpy(), df_b.to_numpy())
  res = bimatrix_game.support_enumeration()
  print(list(res))

  try:
    res = bimatrix_solve(df_a, df_b)
  except Exception as e:
    pass

  return res


def solve_risk_decision(df):
  """
  Задача 3
  
  
  """
  risk_vector = df.iloc[-1, :]
  df_vals = df.iloc[:-1, :]

  # Кртерий Лапласа
  df_coef = df_vals.copy()
  df_coef.index = [f"{i}_{x}" for i, x in enumerate(df_coef.index)]
  df_coef = df_coef.rename(columns={x:f"{y+1}_{x}" for x,y in zip(df_coef.columns,range(0,len(df_coef.columns)))})

  for i in range(df_coef.shape[0]):
    df_coef.iloc[i] = df_coef.iloc[i].apply(lambda x: x*(1/len(risk_vector)))
  df_coef['max_vals'] = df_coef.sum(axis = 1)
  df_coef = df_coef[df_coef['max_vals'] == df_coef['max_vals'].max()]


  sub_task_1 = [(int(i)+1, val) for i, val in [(k.split("_")) for k in list(df_coef.index)]]
  sub_task_2 = df_coef['max_vals'].max()

  # Критерий Байеса
  df_coef = df_vals.copy()
  df_coef.index = [f"{i}_{x}" for i, x in enumerate(df_coef.index)]
  df_coef = df_coef.rename(columns={x:f"{y+1}_{x}" for x,y in zip(df_coef.columns,range(0,len(df_coef.columns)))})

  for i, risk in enumerate(risk_vector):
    df_coef.iloc[:, i] = df_coef.iloc[:, i].apply(lambda x: x*risk)

  df_coef['max_vals'] = df_coef.sum(axis = 1)
  df_coef = df_coef[df_coef['max_vals'] == df_coef['max_vals'].max()]
  sub_task_3 = [(int(i)+1, val) for i, val in [(k.split("_")) for k in list(df_coef.index)]]
  sub_task_4 = df_coef['max_vals'].max()

  # Критерий Гермейера
  df_coef = df_vals.copy()
  df_coef.index = [f"{i}_{x}" for i, x in enumerate(df_coef.index)]
  df_coef = df_coef.rename(columns={x:f"{y+1}_{x}" for x,y in zip(df_coef.columns,range(0,len(df_coef.columns)))})

  to_find_val = df_coef.copy()

  for i, risk in enumerate(risk_vector):
    df_coef.iloc[:, i] = df_coef.iloc[:, i].apply(lambda x: x*risk)

  df_coef['min_vals'] = df_coef.min(axis = 1)
  df_coef = df_coef[df_coef['min_vals'] == df_coef['min_vals'].max()]

  a, b = df_coef.stack().idxmin()
  sub_task_5 = [(int(i)+1, val) for i, val in [(k.split("_")) for k in list(df_coef.index)]]
  sub_task_6 = (f"{df_coef['min_vals'].max()} / {int(to_find_val.loc[[a], [b]].values[0])}", df_coef['min_vals'].max() / int(to_find_val.loc[[a], [b]].values[0]))
 
  # Таблица оптимальных смешанных стратегий для игрока А по критерию Гермейера

  df_coef = df_vals.copy()
  df_arr = df_coef.to_numpy()

  game_1 = nash.Game(df_arr)
  strategy = list(game_1.support_enumeration())

  #nash
  print(strategy)

  try: 
    sub_task_7 = strategy[0][0]
    sub_task_8 = strategy[0][0].dot(df_arr).dot(strategy[0][1])

    df_5 = pd.DataFrame(columns=df.columns)
    data_to_append = {}
    for i in range(len(df.columns)):
      data_to_append[df.columns[i]] = sub_task_7[i]

    df_5 = df_5.append(data_to_append, ignore_index=True)
    sub_task_7 = df_5

  except Exception as e:
    sub_task_7 = 'Не найдено'
    sub_task_8 = 'Не найдено'

  print(sub_task_5)
  print(sub_task_6)

 
  # print()
  # row_sum = df_coef.sum(axis = 0)
  # print(row_sum)

  print(sub_task_1, sub_task_2, sub_task_3, sub_task_4, sub_task_5, sub_task_6, sub_task_7, sub_task_8)
  return sub_task_1, sub_task_2, sub_task_3, sub_task_4, sub_task_5, sub_task_6, sub_task_7, sub_task_8


def solve_decision_under_uncertainty(df):
  """
  Задача 4
  
  
  """
  df_prep = df.copy()
  df_prep.index = [f"{i}_{x}" for i, x in enumerate(df_prep.index)]
  df_prep = df_prep.rename(columns={x:f"{y+1}_{x}" for x,y in zip(df_prep.columns,range(0,len(df_prep.columns)))})

  # Критерий пессимизма
  df_coef = df_prep.copy()
  df_coef['min_vals'] = df_coef.min(axis = 1)

  sub_task_1 = []
  df_min = df_coef[df_coef['min_vals'] == df_coef['min_vals'].min()]
  

  for i in list(df_min.index):
    sub_task_1.append((int(i.split("_")[0])+1, i.split("_")[1]))
  sub_task_2 = int(df_coef['min_vals'].min())

  # Критерий Вальда

  sub_task_5 = []
  df_vald = df_coef[df_coef['min_vals'] == df_coef['min_vals'].max()]
  for i in list(df_vald.index):
    sub_task_5.append((int(i.split("_")[0])+1, i.split("_")[1]))

  sub_task_6 = int(df_coef['min_vals'].max())


  # В методичке приведенный пример содержит ошибку, тк при
  # Критерий оптимизма 
  df_coef.drop(columns=['min_vals'], inplace=True)
  df_coef['max_vals'] = df_coef.max(axis = 1)

  sub_task_3 = []
  df_max = df_coef[df_coef['max_vals'] == df_coef['max_vals'].max()]
  for i in list(df_max.index):
    sub_task_3.append((int(i.split("_")[0])+1, i.split("_")[1]))

  sub_task_4 = int(df_coef['max_vals'].max())


  # Критерий Сэвиджа
  # Построение Матрицы рисков 
  risk_df = df_prep.copy()
  
  for i, col in enumerate(list(risk_df.columns)):
    max_col_val = risk_df[col].max()
    risk_df[col] = risk_df[col].apply(lambda x: max_col_val-x)

  sub_task_9 = []
  risk_df['max_vals'] =  risk_df.max(axis = 1)
  df_max = risk_df[risk_df['max_vals'] == risk_df['max_vals'].min()]
  for i in list(df_max.index):
    sub_task_9.append((int(i.split("_")[0])+1, i.split("_")[1]))

  sub_task_10 = int(risk_df['max_vals'].min())
    
  print(sub_task_3) #?
  print(sub_task_4) #?
  sub_task_8 = ''
  sub_task_7 = ''

  # Линейная свертка склонности к риску по критерию Гурвица
  df_coef = df_prep.copy()
  alpha_values = [round(i, 2) for i in np.arange(0, 1.1, 0.1)]

  df_gurv = pd.DataFrame(columns=alpha_values, index=df_coef.index)


  for i, row in df_coef.iterrows():
    gurv_alpha_row = []
    for alpha in alpha_values:
      h_val = row.max()*alpha + row.min()*(1-alpha)
      gurv_alpha_row.append(h_val)
    df_gurv.loc[i] = gurv_alpha_row

  max_values_for_each_alpha = df_gurv.max(axis=0)
  max_values_for_each_alpha.name = 'max'
  df_gurv = df_gurv.append(max_values_for_each_alpha)

  sub_task_7 = df_gurv

  df_gurv_melt = df_gurv.iloc[:-1].reset_index()
  df_gurv_melt = df_gurv_melt.melt(id_vars='index')
  max_line = list(df_gurv.iloc[-1])

  fig = plt.figure()
  ax = fig.add_subplot()

  print(max_line)
  sns_plot = sns.lineplot(data=max_line, linewidth=4)
  sns_plot = sns.barplot(data=df_gurv_melt, hue='index', x='variable', y='value')

  ax.set_title('Гистограмма распределения оптимальной цены игры по критерию Гурвица')
  ax.set_xlabel('Величина склонности к риску')
  ax.set_ylabel('Цена игры')
  plt.grid()

  sub_task_8 = ("iamplot", max_line, df_gurv_melt)

  return sub_task_1, sub_task_2, sub_task_3, sub_task_4, sub_task_5, sub_task_6, sub_task_7, sub_task_8, sub_task_9, sub_task_10


def main_solve_tasks():
  file_1 = os.path.abspath(ROOT_DIR + '/data/task1_1.csv')

  file_2_a = os.path.abspath(ROOT_DIR + '/data/task1_2_a.csv')
  file_2_b = os.path.abspath(ROOT_DIR + '/data/task1_2_b.csv')

  file_3 = os.path.abspath(ROOT_DIR + '/data/task1_3.csv')
  file_4 = os.path.abspath(ROOT_DIR + '/data/task1_4.csv')

  # task_n = int(input("Task num -> "))
  task_n = 3

  if task_n == 1:
    df = get_input_data_task1()

    if isinstance(df, pd.DataFrame):
      print("All data are validated. Starting solving the game ...")
      results = solve_zero_sum_game(df)
      return results

  elif  task_n == 2:
    # df_a, df_b = get_input_data_task2()
    df_a = get_csv_data(1, file_2_a)
    df_b = get_csv_data(1, file_2_b)


    if isinstance(df_a, pd.DataFrame) and isinstance(df_b, pd.DataFrame):
      print("All data are validated. Starting solving the game ...")
      results = solve_bimatrix_game(df_a, df_b)
      return results

  elif  task_n == 3:
    df = get_csv_data(3, file_3)

    if isinstance(df, pd.DataFrame):
      print("All data are validated. Starting solving the game ...")
      results = solve_risk_decision(df)
      return results

  elif  task_n == 4:
    df = get_csv_data(4, file_4)

    if isinstance(df, pd.DataFrame):
      print("All data are validated. Starting solving the game ...")
      results = solve_decision_under_uncertainty(df)
      return results

  else:
    pass

  # if isinstance(df, pd.DataFrame):
  #   print("All data are validated. Starting solving the game ...")
  #   results = solve_zero_sum_game(df)


if __name__ == '__main__':
  main_solve_tasks()
  