from pickletools import markobject
from unittest import result
import streamlit as st

from task1.solve_task_1 import *
from task1.random_facts import all_facts

import pandas as pd
import numpy as np
import seaborn as sns
import string

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))


def main_page():
  st.markdown("### Приложение для решение задач теории игр")
  st.markdown("**Работу выполнил**")
  st.markdown("Нуралиев Р.Р., группа ПИ19-4")
  st.markdown("___")

  # st.markdown("Поддержи другие проекты автора, подпишись сюда -> [Click Me](https://t.me/obsessionnetwork)")
  url = 'https://www.streamlit.io/'
  st.sidebar.markdown("# 🏠 Главная ")
  

def task1_page():
  st.markdown("### Задание 1. Антагонистическая игра.")
  data_inp_option = st.selectbox('Выберите способ ввода данных', ('Файл .csv', 'Случайная генерация', 'Значения из примера'))

  def show_results(df):
    st.markdown("___")
    st.markdown("Исходная матрица")
    st.write(df)

    results = solve_zero_sum_game(df)

    tasks_descriptions = ['а) Оптимальная чистая стратегия для игрока А: ',
      'б) Цена игры для игрока А при выборе чистой оптимальной стратегии: ',
      'в) Оптимальная чистая стратегия для игрока Б: ',
      'г) Цена игры для игрока Б при выборе чистой оптимальной стратегии: ',
      'д) Таблица смешанных стратегий для игрока А: ',
      'е) Цена игры для игрока А при выборе смешанной оптимальной стратегии: ',
      ]

    for res_val, desc in zip(results, tasks_descriptions):
      st.markdown("#####"+ f' {desc} ')
      
      if isinstance(res_val, tuple):
        st.code(res_val[0] + " " + res_val[1])
      elif isinstance(res_val, pd.DataFrame):
        st.write(res_val)
      else:
        st.code(res_val)

  if data_inp_option == 'Файл .csv':
    st.warning("Обратите внимание, что ячейка первой строки первого столба должна быть пустой (A1)")

    uploaded_file = st.file_uploader("Choose a file")
    if uploaded_file is not None:
      df = pd.read_csv(uploaded_file, index_col=0)
      val_res = validate_dataframe(df, float_val=False, st_app=True)

      if not val_res is True:
         st.error(f"Проблемы с чтением файла. {val_res}")

      else:
        show_results(df)

  elif data_inp_option == 'Случайная генерация':
    st.markdown("Случайная генерация")
    
    df = pd.DataFrame(np.random.randint(0, 5,size=(4, 5)), columns=list(string.ascii_uppercase)[:5])
    show_results(df)


  elif data_inp_option == 'Значения из примера':
    st.markdown('Значения из примера')
    df = pd.read_csv(ROOT_DIR+"/task1/data/task1_1.csv", index_col=0)
    val_res = validate_dataframe(df, float_val=False, st_app=True)

    if not val_res is True:
        st.error(f"Проблемы с чтением файла. {val_res}")

    else:
      show_results(df)



  # st.sidebar.markdown("sdfsd")


def task2_page():
  st.markdown("### Задание 2. Биматричная игра.")
  data_inp_option = st.selectbox('Выберите способ ввода данных', ('Файл .csv', 'Случайная генерация', 'Значения из примера'))
  
  if data_inp_option == 'Файл .csv':
    st.warning("Обратите внимание, что ячейка первой строки первого столба должна быть пустой (A1)")
    uploaded_file = st.file_uploader("Загрузите файл с матрицой для игрока А")
    uploaded_file_2 = st.file_uploader("Загрузите файл с матрицой для игрока Б")
    if uploaded_file is not None and uploaded_file_2 is not None:
      df_a = pd.read_csv(uploaded_file, index_col=0)
      val_res_a = validate_dataframe(df_a, float_val=False, st_app=True)

      df_b = pd.read_csv(uploaded_file, index_col=0)
      val_res_b = validate_dataframe(df_b, float_val=False, st_app=True)

      if not val_res_a is True:
         st.error(f"Проблемы с чтением файла для игрока А. {val_res_a}")

      elif not val_res_b is True:
         st.error(f"Проблемы с чтением файла для игрока Б. {val_res_b}")

      else:
        st.markdown("___")
        st.markdown("Исходная матрица игрока А")
        st.write(df_a)

        st.markdown("Исходная матрица игрока А")
        st.write(df_b)

  elif data_inp_option == 'Случайная генерация':
    st.warning("Обратите внимание, что ячейка первой строки первого столба должна быть пустой (A1)")
    # uploaded_file = st.file_uploader("Загрузите файл с матрицой для игрока А")
    # uploaded_file_2 = st.file_uploader("Загрузите файл с матрицой для игрока Б")
    # if uploaded_file is not None and uploaded_file_2 is not None:
    #   df_a = pd.read_csv(uploaded_file, index_col=0)
    #   val_res_a = validate_dataframe(df_a, float_val=False, st_app=True)

    #   df_b = pd.read_csv(uploaded_file, index_col=0)
    #   val_res_b = validate_dataframe(df_b, float_val=False, st_app=True)

    #   if not val_res_a is True:
    #      st.error(f"Проблемы с чтением файла для игрока А. {val_res_a}")

    #   elif not val_res_b is True:
    #      st.error(f"Проблемы с чтением файла для игрока Б. {val_res_b}")

    #   else:
    #     st.markdown("___")
    #     st.markdown("Исходная матрица игрока А")
    #     st.write(df_a)

    #     st.markdown("Исходная матрица игрока А")
    #     st.write(df_b)

  elif data_inp_option == 'Значения из примера':
    st.warning("Обратите внимание, что ячейка первой строки первого столба должна быть пустой (A1)")


def task3_page():
  st.markdown("### Задание 3. Оптимальное решение в условиях риска.")
  data_inp_option = st.selectbox('Выберите способ ввода данных', ('Файл .csv', 'Случайная генерация', 'Значения из примера'))
  
  def show_results(df):
    st.markdown("___")
    st.markdown("Исходная матрица")
    st.write(df)

    results = solve_risk_decision(df)

    tasks_descriptions = ['а) Оптимальная стратегия игрока А по критерию Лапласа: ',
          'б) Цена игры с оптимальной стратегии по критерию Лапласа: ',
          'в) Оптимальная стратегия игрока А по критерию Баеса: ',
          'г) Цена игры с оптимальной стратегии по критерию Баеса: ',
          'д) Оптимальная чистая стратегия игрока А по критерию Гермейера: ',
          'е) Цена игры с оптимальной чистой стратегии по критерию Гермейера: ',
          'ж) Таблица оптимальных смешанных стратегий для игрока А по критерию Гермейера: ',
          '3) Цена игры для игрока А при выборе смешанной оптимальной стратегии по критерию Гермейера: '
          ]

    for res_val, desc in zip(results, tasks_descriptions):
      st.markdown("#####"+ f' {desc} ')
      
      if isinstance(res_val, tuple):
        st.code(str(res_val[0]) + " = " + str(res_val[1]))
      elif isinstance(res_val, list):
        for val in res_val:
          st.code(str(val[0]) + " " + str(val[1]))
      elif isinstance(res_val, pd.DataFrame):
        st.write(res_val)
      else:
        st.code(res_val)

  if data_inp_option == 'Файл .csv':
    st.warning("Обратите внимание, что ячейка первой строки первого столба должна быть пустой (A1). Последняя СТРОКА в файле должена содержать данные о вероятностях")
    uploaded_file = st.file_uploader("Choose a file")
    if uploaded_file is not None:
      df = pd.read_csv(uploaded_file, index_col=0)
      val_res = validate_dataframe(df, float_val=True, st_app=True)

      if not val_res is True:
         st.error(f"Проблемы с чтением файла. {val_res}")

      else:
        show_results(df)

  elif data_inp_option == 'Значения из примера':
    st.markdown('Значения из примера')
    df = pd.read_csv(ROOT_DIR+"/task1/data/task1_3.csv", index_col=0)
    val_res = validate_dataframe(df, float_val=True, st_app=True)

    if not val_res is True:
      st.error(f"Проблемы с чтением файла. {val_res}")
    else:
      show_results(df)

  elif data_inp_option == 'Случайная генерация':
    st.markdown("Случайная генерация")
    
    df = pd.DataFrame(np.random.randint(1, 10,size=(4, 4)), columns=['Рецессия', 'Стагнация', 'Оживление', 'Подъем'], index=['Продукты', 'Косметика', 'Одежда', 'Бытовая химия'])
    ver_vals = []
    for i in range(4):
      ver_vals.append(round(np.random.uniform(0.1 , 1), 2))
    
    ser = pd.Series(ver_vals, index=['Рецессия', 'Стагнация', 'Оживление', 'Подъем'])
    ser.name = 'Вероятность'
    print(ser)
    df = df.append(ser)
    show_results(df)



def task4_page():
  st.markdown("### Задание 4. Оптимальное решение в условиях неопределенности.")
  data_inp_option = st.selectbox('Выберите способ ввода данных', ('Файл .csv', 'Случайная генерация', 'Значения из примера'))
  
  def show_results(df):
    st.markdown("___")
    st.markdown("Исходная матрица")
    st.write(df)

    results = solve_decision_under_uncertainty(df)

    tasks_descriptions = ['а) Оптимальная стратегия игрока А по критерию пессимизма: ',
          'б) Цена игры оптимальной стратегии по критерию пессимизма: ',
          'в) Оптимальная стратегия игрока А по критерию оптимизма: ',
          'г) Цена игры оптимальной стратегии по критерию оптимизма: ',
          'д) Оптимальная стратегия игрока А по критерию Вальда: ',
          'е) Цена игры оптимальной стратегии по критерию Вальда: ',
          'ж) Линейная свертка склонности к риску по критерию Гурвица: ',
          'з) Гистограмма (диаграмма) максимумов линейной свертки по критерию Гурвица: ',
          'и) Оптимальная стратегия игрока А по критерию Сэвиджа: ',
          'к) Величина минимальной недополученной прибыли по критерию Сэвиджа: '
          ]

    for res_val, desc in zip(results, tasks_descriptions):
      st.markdown("#####"+ f' {desc} ')
      
      if isinstance(res_val, tuple):
        if res_val[0] == "iamplot":
          fig = plt.figure()
          ax = fig.add_subplot()

          max_line = res_val[1]
          df_gurv_melt = res_val[2]

          print(max_line)
          sns_plot = sns.lineplot(data=max_line, linewidth=4)
          sns_plot = sns.barplot(data=df_gurv_melt, hue='index', x='variable', y='value')

          ax.set_title('Гистограмма распределения оптимальной цены игры по критерию Гурвица')
          ax.set_xlabel('Величина склонности к риску')
          ax.set_ylabel('Цена игры')
          plt.grid()
          st.pyplot(plt)

          pass
        else:
          st.code(res_val[0] + " " + res_val[1])

      elif isinstance(res_val, list):
        for val in res_val:
          st.code(str(val[0]) + " " + str(val[1]))

      elif isinstance(res_val, pd.DataFrame):
        st.write(res_val)

      else:
        st.code(res_val)


  if data_inp_option == 'Файл .csv':
    st.warning("Обратите внимание, что ячейка первой строки первого столба должна быть пустой (A1)")
    uploaded_file = st.file_uploader("Choose a file")
    if uploaded_file is not None:
      df = pd.read_csv(uploaded_file, index_col=0)
      val_res = validate_dataframe(df, float_val=False, st_app=True)

      if not val_res is True:
         st.error(f"Проблемы с чтением файла. {val_res}")

      else:
        show_results(df)

  elif data_inp_option == 'Значения из примера':
    st.markdown('Значения из примера')
    df = pd.read_csv(ROOT_DIR+"/task1/data/task1_4.csv", index_col=0)
    val_res = validate_dataframe(df, float_val=False, st_app=True)

    if not val_res is True:
      st.error(f"Проблемы с чтением файла. {val_res}")
    else:
      show_results(df)
  
  elif data_inp_option == 'Случайная генерация':
    st.markdown('Случайная генерация')
    df = pd.DataFrame(np.random.randint(1, 10,size=(4, 4)), columns=['Рецессия', 'Стагнация', 'Оживление', 'Подъем'], index=['Продукты', 'Косметика', 'Одежда', 'Бытовая химия'])
    show_results(df)

def main():
  selected_page = st.sidebar.selectbox("Выбрать страницу", page_names_to_funcs.keys())
  page_names_to_funcs[selected_page]()


# st.sidebar.markdown("1️⃣")
page_names_to_funcs = {
  "🏠 Главная": main_page,
  "1️⃣ Антагонистическая игра": task1_page,
  "2️⃣ Биматричная игра": task2_page,
  "3️⃣ Оптимальное решение в условиях риска": task3_page,
  "4️⃣ Оптимальное решение в условиях неопределенности": task4_page
}


if __name__ == '__main__':
  main()